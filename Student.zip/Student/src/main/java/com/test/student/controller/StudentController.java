package com.test.student.controller;

import com.test.student.model.Student;
import com.test.student.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class StudentController {
    @Autowired
    StudentRepository studentRepository;

    /**
     * Get Students
     * @return ResponseEntity
     */
    @GetMapping("/students")
    public ResponseEntity<List<Student>> getStudents() {
        try {
            return new ResponseEntity<>(studentRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Create new student
     * @param student
     * @return ResponseEntity
     */
    @PostMapping("/student")
    public ResponseEntity<Student> newStudent(@RequestBody Student student) {
        Student newStudent = studentRepository
                .save(Student.builder()
                        .name(student.getName())
                        .course(student.getCourse())
                        .enrolled(true)
                        .build());
        return new ResponseEntity<>(newStudent, HttpStatus.OK);
    }

    /**
     * Get the student by id
     * @param id
     * @return ResponseEntity
     */
    @GetMapping("/student/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable("id") long id) {
        try {
            Student studentObj = getStudentId(id);

            if (studentObj != null) {
                return new ResponseEntity<>(studentObj, HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Update Student by id
     * @param id
     * @param student
     * @return
     */
    @PutMapping("/student/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable("id") long id, @RequestBody Student student) {
        Student studentObj = getStudentId(id);

        if (studentObj != null) {
            studentObj.setName(student.getName());
            studentObj.setCourse(student.getCourse());
            return new ResponseEntity<>(studentRepository.save(studentObj), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Delete Student by Id
     * @param id
     * @return ResponseEntity
     */
    @DeleteMapping("/student/{id}")
    public ResponseEntity<HttpStatus> deleteStudentById(@PathVariable("id") long id) {
        try {
            Student emp = getStudentId(id);
            if (emp != null) {
                studentRepository.deleteById(id);
                return new ResponseEntity<>(HttpStatus.OK);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Delete all students
     * @return ResponseEntity
     */
    @DeleteMapping("/students")
    public ResponseEntity<HttpStatus> deleteAllStudents() {
        try {
            studentRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get student record by ID
     * @param id
     * @return Student
     */
    private Student getStudentId(long id) {
        Optional<Student> studentObj = studentRepository.findById(id);
        if (studentObj.isPresent()) {
            return studentObj.get();
        }
        return null;
    }
}
